import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter : RecyclerView.Adapter<ItemAdapter.ViewHolder>() {
    private var items: List<Pair<Int, List<Item>>> = emptyList()

    fun submitList(newItems: List<Pair<Int, List<Item>>>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (listId, groupItems) = items[position]
        holder.bind(listId, groupItems)
    }

    override fun getItemCount() = items.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val listIdTextView: TextView = itemView.findViewById(R.id.listIdTextView)
        private val itemsTextView: TextView = itemView.findViewById(R.id.itemsTextView)

        fun bind(listId: Int, items: List<Item>) {
            listIdTextView.text = "List ID: $listId"
            itemsTextView.text = items.joinToString("\n") { it.name ?: "" }
        }
    }
}