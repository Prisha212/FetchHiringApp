
package com.example.fetchhiringapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch


class MainViewModel : ViewModel() {
    private val _items = MutableStateFlow<List<Pair<Int, List<Item>>>>(emptyList())
    val items: StateFlow<List<Pair<Int, List<Item>>>> = _items


    fun fetchItems() {
        viewModelScope.launch {
            try {
                val fetchedItems = RetrofitClient.apiService.getItems()
                val processedItems = processItems(fetchedItems)
                _items.value = processedItems
            } catch (e: Exception) {
                // Handle error
            }
        }
    }

    private fun processItems(items: List<Item>): List<Pair<Int, List<Item>>> {
        return items
            .filter { !it.name.isNullOrBlank() }
            .groupBy { it.listId }
            .mapValues { (_, items) -> items.sortedBy { it.name } }
            .toList()
            .sortedBy { it.first }
    }
}